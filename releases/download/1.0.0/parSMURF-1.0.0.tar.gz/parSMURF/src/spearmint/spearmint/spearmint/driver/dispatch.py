

class DispatchDriver(object):
    def submit_job(job):
        '''Schedule a job for execution.'''
        pass


    def is_proc_alive(job_ids):
        '''Check on the status of executing jobs.'''
        pass
